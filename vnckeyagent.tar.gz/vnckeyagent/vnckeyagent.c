//gcc vnckeyagent.c  /usr/local/lib/libvncclient.a -ljpeg -lz -o vnckeyagent
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

#include <time.h>
#include <errno.h>

#include <sys/socket.h>
#include <sys/stat.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <net/if.h>
#include <netinet/in.h>

#include <sys/ioctl.h>

#include <rfb/rfbclient.h>

typedef struct {
	unsigned int dev_type;		// 设备类型
	unsigned int sequence_num; 	// 序列号，由终端制定
	unsigned int key_value; 	// 键值
	unsigned int key_status; 	// 键值类型
}keymsg;



int get_keyboard_value(keymsg* key_msg,int opt)//键盘
{
	switch(key_msg->key_value)
	{
		case 0x4 :		if(opt)		return XK_A;	return XK_a;
		case 0x5 :  	if(opt)		return XK_B;	return XK_b;
		case 0x6 :  	if(opt)		return XK_C;	return XK_c;
		case 0x7 :  	if(opt)		return XK_D;	return XK_d;
		case 0x8 :  	if(opt)		return XK_E;	return XK_e;
		case 0x9 :  	if(opt)		return XK_F;	return XK_f;
		case 0xa :  	if(opt)		return XK_G;	return XK_g;
		case 0xb :  	if(opt)		return XK_H;	return XK_h;
		case 0xc :  	if(opt)		return XK_I;	return XK_i;
		case 0xd :  	if(opt)		return XK_J;	return XK_j;
		case 0xe :  	if(opt)		return XK_K;	return XK_k;
		case 0xf :  	if(opt)		return XK_L;	return XK_l;
		case 0x10:  	if(opt)		return XK_M;	return XK_m;
		case 0x11:  	if(opt)		return XK_N;	return XK_n;
		case 0x12:  	if(opt)		return XK_O;	return XK_o;
		case 0x13:  	if(opt)		return XK_P;	return XK_p;
		case 0x14:  	if(opt)		return XK_Q;	return XK_q;
		case 0x15:  	if(opt)		return XK_R;	return XK_r;
		case 0x16:  	if(opt)		return XK_S;	return XK_s;
		case 0x17:  	if(opt)		return XK_T;	return XK_t;
		case 0x18:  	if(opt)		return XK_U;	return XK_u;
		case 0x19:  	if(opt)		return XK_V;	return XK_v;
		case 0x1a: 		if(opt)		return XK_W;	return XK_w;
		case 0x1b: 		if(opt)		return XK_X;	return XK_x;
		case 0x1c: 		if(opt)		return XK_Y;	return XK_y;
		case 0x1d:	 	if(opt)		return XK_Z;	return XK_z;
		case 0x1e: 		if(opt)		return XK_exclam;	return XK_1;
		case 0x1f: 		if(opt)		return XK_at;		return XK_2;
		case 0x20:		if(opt)		return XK_numbersign;	return XK_3;
		case 0x21:		if(opt)		return XK_dollar;	return XK_4;
		case 0x22:		if(opt)		return XK_percent;	return XK_5;
		case 0x23:		if(opt)		return XK_asciicircum;	return XK_6;
		case 0x24:		if(opt)		return XK_ampersand;	return XK_7;
		case 0x25:		if(opt)		return XK_asterisk;	return XK_8;
		case 0x26:		if(opt)		return XK_parenleft;	return XK_9;
		case 0x27:		if(opt)		return XK_parenright;	return XK_0;
		case 0x28:		return XK_KP_Enter;
		case 0x29:		return XK_Escape;
		case 0x2a:		return XK_BackSpace;
		case 0x2b:		return XK_Tab;
		case 0x2c:		return XK_space;
		case 0x2d:		if(opt)		return XK_underscore;	return XK_minus;
		case 0x2e:		if(opt)		return XK_plus;		return XK_equal;
		case 0x2f:		if(opt)		return XK_braceleft;	return XK_bracketleft;
		case 0x30:		if(opt)		return XK_braceright;	return XK_bracketright;
		case 0x31:		if(opt)		return XK_bar;		return XK_backslash;
		case 0x32:		if(opt)		return XK_quoteleft;	return XK_asciitilde;
		case 0x33:		if(opt)		return XK_colon;	return XK_semicolon;
		case 0x34:		if(opt)		return XK_quotedbl;	return XK_apostrophe;
		case 0x35:		if(opt)		return XK_asciitilde;	return XK_grave;
		case 0x36:		if(opt)		return XK_less;		return XK_comma;
		case 0x37:		if(opt)		return XK_greater;	return XK_period;
		case 0x38:		if(opt)		return XK_question;	return XK_slash;
		case 0x39:		return XK_Caps_Lock;
		case 0xaa:		return XK_Alt_L;
		case 0xa9:		return XK_Control_L;
		case 0xa8:		return XK_Shift_L;
		case 0x3a:		return XK_F1;
		case 0x3b:		return XK_F2;
		case 0x3c:		return XK_F3;
		case 0x3d:		return XK_F4;
		case 0x3e:		return XK_F5;
		case 0x3f:		return XK_F6;
		case 0x40:		return XK_F7;
		case 0x41:		return XK_F8;
		case 0x42:		return XK_F9;
		case 0x43:		return XK_F10;
		case 0x44:		return XK_F11;
		case 0x45:		return XK_F12;

		case 0x49:              return XK_Insert;
		case 0x4a:		return XK_Home;
		case 0x4b:		return XK_Page_Up;
		case 0x4c:		return XK_Delete;
		case 0x4d:		return XK_End;
		case 0x4e:		return XK_Page_Down;
		case 0x4f:		return XK_Right;
		case 0x50:		return XK_Left;
		case 0x51:		return XK_Down;
		case 0x52:		return XK_Up;
		default:		return -1;
	}
}


int main(int argc,char **argv)
{
	if(argc != 3)
	{
		printf("usage: %s listen_port server:port\n", argv[0]);
		return -1;
	}
	rfbBool rfb_ret_bool = FALSE;
	rfbClient* vnc_client;
	int listen_port = atoi(argv[1]);
	
	printf("%s is Start... vncserver=[%s] key_port=[%d]\n", argv[0],argv[2],listen_port);

	vnc_client = rfbGetClient(8,3,4);
	if(!vnc_client)
	{
		printf("rfbGetClient error!\n");
		return -2;
	}
	
	rfb_ret_bool = rfbInitClient(vnc_client,&argc,argv);
	if (!rfb_ret_bool)
	{
		printf("rfbInitClient error!\n");
		return -3;
	}
	
	int sock_fd;
	struct sockaddr_in servaddr;
	struct sockaddr_in cliaddr;
	socklen_t addrlen = sizeof(cliaddr);
	char buffer[1024];
	int recvlen = -1;
	keymsg *p_msg = NULL;
	int opt = 1;
	
	sock_fd = socket(AF_INET, SOCK_DGRAM, 0);
	if (sock_fd == -1)
	{
		printf("socket create error!\n");
		return -4;
	}	
	
	setsockopt(sock_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
	
	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr.sin_port = htons(listen_port);

	if(bind(sock_fd, (struct sockaddr *)&servaddr, sizeof(servaddr)) == -1)
	{
		printf("socket bind error!\n");
		return -5;
	}
	
	int shift = 0;
	rfbBool down = 1;
	int key = -1;
			
	while(1)
	{
		memset(buffer,0,sizeof(buffer));
		recvlen = recvfrom(sock_fd, buffer, sizeof(buffer), 0, (struct sockaddr *)&cliaddr, &addrlen);
		if(recvlen <= 0)
			continue;
			
		p_msg = (keymsg*)buffer;
		printf("Recv Key dev_type=%d,sequence_num=%d,key_value=%d,key_status=%d\n",p_msg->dev_type,p_msg->sequence_num,p_msg->key_value,p_msg->key_status);
		
		if(p_msg->dev_type == 1001)//遥控器
		{
			printf("Not Implemented\n");
		}
		else if(p_msg->dev_type == 1002)//同1001
		{
			printf("Not Implemented\n");
		}
		else if(p_msg->dev_type == 1003)//游戏手柄设备
		{
			printf("Not Implemented\n");
		}
		else if(p_msg->dev_type == 1004)//键盘设备
		{
			if(p_msg->key_status == 2)
				down = 1;
			else if(p_msg->key_status == 3)
				down = 0;
				
			key = get_keyboard_value(p_msg,shift);//键盘
			if(key == -1)
			{
				printf("error key\n");
				continue;
			}
			
			if(XK_Shift_L == key && p_msg->key_status == 2)
				shift=1;
			else if(XK_Shift_L == key  && p_msg->key_status == 3)
				shift=0;
				
			rfb_ret_bool = SendKeyEvent(vnc_client,key,down);
			if(rfb_ret_bool)
				printf("Send key success\n");
			else
				printf("Send key fail\n");
		}
		else if(p_msg->dev_type == 1005)//鼠标设备
		{
			printf("Not Implemented\n");
		}
		else
		{
			printf("Unknow dev type :%d\n",p_msg->dev_type);
		}
		
	}
	
	return 1;
	
}
