#!/bin/bash

index=1
vncaddr=127.0.0.1:5901
vnckeyport=62001
width=1280
height=720
dpi=1280x720
pids=1024:1:256:257
gopsize=5:100

#url=http://218.108.172.130:7080/bbcv/csp_v4/Cisco/index.html
url=http://192.168.70.106/cisco_test1/tv2.0352.html
#url=channel1.html
#url=http://218.108.50.246/ott/second/menusv3/index.html
#url=http://218.108.50.246/moviegallery/movie-gallery.html
#url=http://192.168.100.86:8181/ccbnNew/win8full/index.html
#url=http://192.168.70.106/wasu/youhua/singleVideo/index.html
#url=http://192.168.70.106/wasu/youhua/svn2/tv2.0.html

bitrate=4000000
addr=192.168.60.248:14000



sudo ./Xvnc :$index -desktop X -depth 24 -geometry $dpi &

export DISPLAY=:$index
export PULSE_SINK=$index
export PULSE_LATENCY_MSEC=0
#export LIBGL_DEBUG=verbose

/opt/VirtualGL/bin/vglrun -c proxy google-chrome --display=:$index --in-process-gpu --kiosk --no-first-run --disable-accelerated-video --disable-hang-monitor --user-data-dir=chrome1 $url &

./AudioRecord $index &

sudo ./avencoder --index $index --width $width --height $height --bitrate $bitrate --pids $pids --gopsize $gopsize --destaddr $addr &

sleep 1

./vnckeyagent $vnckeyport $vncaddr &
