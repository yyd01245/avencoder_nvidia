#!/bin/bash

sudo killall vnckeyagent

sudo killall Xvnc

sudo killall AudioRecord

sudo killall avencoder
