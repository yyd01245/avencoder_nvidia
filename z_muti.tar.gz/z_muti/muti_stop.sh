#!/bin/bash


xvnc_pid=0
chrome_pid=0
audiorecord_pid=0
avencoder_pid=0
vnckeyagent_pid=0
muti_start_pid=0

while read line
do
	#echo @@@$line
	xvnc_pid=`echo $line|awk -F '|' '{print $1}'`
	chrome_pid=`echo $line|awk -F '|' '{print $2}'`
	audiorecord_pid=`echo $line|awk -F '|' '{print $3}'`
	avencoder_pid=`echo $line|awk -F '|' '{print $4}'`
	vnckeyagent_pid=`echo $line|awk -F '|' '{print $5}'`
	echo xvnc_pid=$xvnc_pid chrome_pid=$chrome_pid audiorecord_pid=$audiorecord_pid avencoder_pid=$avencoder_pid vnckeyagent_pid=$vnckeyagent_pid
	
	sudo kill -9 $xvnc_pid
	sudo kill -9 $chrome_pid
	sudo kill -9 $audiorecord_pid
	sudo kill -9 $avencoder_pid
	sudo kill -9 $vnckeyagent_pid
	
done<pidlist.tmp

sudo killall muti_start

sudo rm -rf pidlist.tmp

sudo rm -rf chrome*
