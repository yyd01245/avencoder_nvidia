//gcc muti_start.c -o muti_start
//./muti_start

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>

#include <sys/types.h>
#include <pwd.h>
#include <signal.h>


int total_num = 1;
int start_index = 1;

int width=1280;
int height=720;
char *pids="1024:1:256:257";
char *gopsize="5:100";
char *url = "http://192.168.70.106/cisco_test1/tv2.0352.html";
int bitrate = 3000000;
char *destip = "192.168.60.248";
int destport = 14000;

char *Xvnc_str = "../test/Xvnc";
char *AudioRecord_str = "../test/AudioRecord";
char *vnckeyagent_str = "../test/vnckeyagent";
char *avencoder_str = "../test/avencoder";

int uid_start = 1000;
int pa_amount = 8;


int start_one(int index,int *xvnc_pid,int *chrome_pid,int *audiorecord_pid,int *avencoder_pid,int *vnckeyagent_pid)
{
	if(index <= 0 || index > 100)
		return -1;

	int uid;
	pid_t pid;
	
	uid = uid_start + (index - 1)/pa_amount;
	struct passwd *my_info = getpwuid(uid);
	printf( "my name =   [%s]\n", my_info->pw_name );
	printf( "my dir =    [%s]\n", my_info->pw_dir );

	//Xvnc
	pid = vfork();

	if (pid < 0)
	{
		printf("%s %d vfork error\n",__FUNCTION__,__LINE__);
		return -2;
	}
	else if (pid == 0)
	{
		char display[32];
		char display_id[32];

		memset(display,0,sizeof(display));
		snprintf(display,sizeof(display),"%dx%d",width,height);

		memset(display_id,0,sizeof(display_id));
		snprintf(display_id,sizeof(display_id),":%d",index);
	
		execl(Xvnc_str,Xvnc_str, display_id,"-desktop","X","-depth","24","-geometry", display, (char *)0);
		printf("%s %d execl Xvnc error\n",__FUNCTION__,__LINE__);
		_exit(1);
	}

	printf("%s %d Xvnc pid=%d\n",__FUNCTION__,__LINE__,pid);

	*xvnc_pid = pid;

	//google-chrome
	pid = vfork();

	if (pid < 0)
	{
		printf("%s %d vfork error\n",__FUNCTION__,__LINE__);
		return -2;
	}
	else if (pid == 0)
	{
		setenv("HOME",my_info->pw_dir,1);
		setuid(uid);

		char copy_cmd[128];
		sprintf(copy_cmd,"cp -r ./.chrome ./chrome%d",index);
		system(copy_cmd);

		char pulse_sink_str[32];
		char display_id[32];
		char display_str[32];
		char chromedata_str[128];

		 int pa_index = index % 8;
		 if (pa_index == 0)
			pa_index = 8;
	
		memset(pulse_sink_str,0,sizeof(pulse_sink_str));
		snprintf(pulse_sink_str,sizeof(pulse_sink_str),"%d",pa_index);
				
		memset(display_id,0,sizeof(display_id));
		snprintf(display_id,sizeof(display_id),":%d",index);

		memset(display_str,0,sizeof(display_str));
		snprintf(display_str,sizeof(display_str),"--display=:%d",index);

		memset(chromedata_str,0,sizeof(chromedata_str));
		snprintf(chromedata_str,sizeof(chromedata_str),"--user-data-dir=chrome%d",index);
		
		setenv("DISPLAY",display_id,1);//set envirmont that can make chrome konw which screen to display
		setenv("PULSE_SINK", pulse_sink_str, 1);
		setenv("PULSE_LATENCY_MSEC", "0", 1);
			
		execl(  "/opt/google/chrome/google-chrome",\
				"google-chrome",\
				display_str,\
				"--kiosk",\
				"--no-first-run",\
				"--in-process-gpu",\
				"--disable-accelerated-video",\
				"--disable-hang-monitor",\
				chromedata_str,\
				url,\
				(char *)0);//3D performance

							
		printf("%s %d execl error\n",__FUNCTION__,__LINE__);
		_exit(1);
	}

	printf("%s %d google-chrome pid=%d\n",__FUNCTION__,__LINE__,pid);
	*chrome_pid = pid;

	sleep(2);
	//AudioRecord
	pid = vfork();

	if (pid < 0)
	{
		printf("%s %d vfork error\n",__FUNCTION__,__LINE__);
		return -2;
	}
	else if (pid == 0)
	{
		setenv("HOME",my_info->pw_dir,1);
		setuid(uid);

		
		char index_str[32];
		
		memset(index_str,0,sizeof(index_str));
		snprintf(index_str,sizeof(index_str),"%d",index);

		execl(AudioRecord_str,AudioRecord_str,index_str,(char *)0);
		printf("%s %d execl AudioRecord error\n",__FUNCTION__,__LINE__);
		_exit(1);
	}

	printf("%s %d AudioRecord pid=%d\n",__FUNCTION__,__LINE__,pid);
	*audiorecord_pid = pid;

	//avencoder
	pid = vfork();

	if (pid < 0)
	{
		printf("%s %d vfork error\n",__FUNCTION__,__LINE__);
		return -2;
	}
	else if (pid == 0)
	{
		char index_str[32];
		char width_str[32];
		char height_str[32];
		char bitrate_str[32];
		char destaddr_str[32];

		memset(index_str,0,sizeof(index_str));
		snprintf(index_str,sizeof(index_str),"%d",index);

		memset(width_str,0,sizeof(width_str));
		snprintf(width_str,sizeof(width_str),"%d",width);

		memset(height_str,0,sizeof(height_str));
		snprintf(height_str,sizeof(height_str),"%d",height);

		memset(bitrate_str,0,sizeof(bitrate_str));
		snprintf(bitrate_str,sizeof(bitrate_str),"%d",bitrate);

		memset(destaddr_str,0,sizeof(destaddr_str));
		snprintf(destaddr_str,sizeof(destaddr_str),"%s:%d",destip,destport+index);

		
		execl(avencoder_str,avencoder_str,"--index",index_str,"--width",width_str,"--height",height_str,"--bitrate",bitrate_str,"--pids",pids,"--gopsize",gopsize,"--destaddr",destaddr_str, (char *)0);
		printf("%s %d execl avencoder error\n",__FUNCTION__,__LINE__);
		_exit(1);
	}

	printf("%s %d avencoder pid=%d\n",__FUNCTION__,__LINE__,pid);
	*avencoder_pid = pid;
	

	//sleep(1);
	//vncconnect
	pid = vfork();

	if (pid < 0)
	{
		printf("%s %d vfork error\n",__FUNCTION__,__LINE__);
		return -2;
	}
	else if (pid == 0)
	{
		char vncaddr[32];
		int vnckeyport;
		char vnckeyport_str[32];
		
		memset(vncaddr,0,sizeof(vncaddr));
		snprintf(vncaddr,sizeof(vncaddr),"127.0.0.1:%d",5900+index);

		vnckeyport = 62000 + index;
		
		memset(vnckeyport_str,0,sizeof(vnckeyport_str));
		snprintf(vnckeyport_str,sizeof(vnckeyport_str),"%d",vnckeyport);
		
		execl(vnckeyagent_str,vnckeyagent_str,vnckeyport_str,vncaddr, (char *)0);
		printf("%s %d execl vnckeyagent error\n",__FUNCTION__,__LINE__);
		_exit(1);
	}

	printf("%s %d vnckeyagent pid=%d\n",__FUNCTION__,__LINE__,pid);
	*vnckeyagent_pid = pid;

	return 0;
	
}

int main(int argc,char **argv)
{
	//����һЩ�����źţ���ֹ�����쳣��ֹ
	signal(SIGINT, SIG_IGN);
	signal(SIGPIPE, SIG_IGN);
	signal(SIGHUP, SIG_IGN);
	signal(SIGQUIT, SIG_IGN);
	signal(SIGFPE, SIG_IGN);
	signal(SIGSEGV, SIG_IGN);

	signal(SIGCLD, SIG_IGN);

	chmod(".",0777);
	
	//deamon
	if(fork())
		return 0;

	//configue

	FILE *fp = NULL;
	char *filename = "pidlist.tmp";
	char tmp_buffer[1024];

	fp = fopen(filename,"a");
	if(fp == NULL)
	{		 
		fprintf(stderr ,"fopen filename %s fail.errno=%d.\n",filename,errno);		 
		return -1;	  
	}
		

	int ret = -1;
	int xvnc_pid;
	int chrome_pid;
	int audiorecord_pid;
	int avencoder_pid;
	int vnckeyagent_pid;
	
	int number = total_num;
	int i = 0;
	while(i < number)
	{
		xvnc_pid = -1;
		chrome_pid = -1;
		audiorecord_pid = -1;
		avencoder_pid = -1;
		ret = start_one(i+start_index,&xvnc_pid,&chrome_pid,&audiorecord_pid,&avencoder_pid,&vnckeyagent_pid);

		memset(tmp_buffer,0,sizeof(tmp_buffer));
		snprintf(tmp_buffer,sizeof(tmp_buffer),"%d|%d|%d|%d|%d\n",xvnc_pid,chrome_pid,audiorecord_pid,avencoder_pid,vnckeyagent_pid);
		fwrite(tmp_buffer,strlen(tmp_buffer),1,fp);

		i++;
	}

	fflush(fp);
	fclose(fp);
	
	while(1)
		sleep(1);
}
